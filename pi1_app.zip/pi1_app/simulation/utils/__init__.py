"""Utilities package.

Keep this __init__ lightweight so the project can run even when optional
dependencies (like paho-mqtt) are not installed (e.g., on a dev PC).
"""
